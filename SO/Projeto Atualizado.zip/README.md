Instalação: 

sudo apt install gcc

sudo apt install make

sudo apt install libncurses-dev


Comando para rodar:
make run


