#ifndef OS_PROJECT_PRINT_H
#define OS_PROJECT_PRINT_H

#include "../process/process.h"
#include "../terminal/terminal.h"


void print_request(process_t* process, int duration);

#endif 